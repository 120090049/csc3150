./program1 ./abort #6
./program1 ./alarm #14
./program1 ./bus   #7
./program1 ./floating #8
./program1 ./hangup #1
./program1 ./illegal_instr #4
./program1 ./interrupt #2
./program1 ./kill #9
./program1 ./pipe #13
./program1 ./quit #3
./program1 ./segment_fault #11
./program1 ./terminate #15
./program1 ./trap #5


./program1 ./normal

./program1 ./stop