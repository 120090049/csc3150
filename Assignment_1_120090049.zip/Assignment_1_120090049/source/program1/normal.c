#include <stdio.h>

int main(int argc,char* argv[]){
	printf("------------CHILD PROCESS START------------\n");
	printf("This is the normal program\n\n");
	printf("------------CHILD PROCESS END------------\n");
	return 0;
}
